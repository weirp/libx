cmd_Release/obj.target/xmljs/src/xml_sax_parser.o := g++ -o Release/obj.target/xmljs/src/xml_sax_parser.o ../src/xml_sax_parser.cc '-DNODE_GYP_MODULE_NAME=xmljs' '-DUSING_UV_SHARED=1' '-DUSING_V8_SHARED=1' '-DV8_DEPRECATION_WARNINGS=1' '-D_GLIBCXX_USE_CXX11_ABI=1' '-D_FILE_OFFSET_BITS=64' '-D_LARGEFILE_SOURCE' '-D__STDC_FORMAT_MACROS' '-DOPENSSL_NO_PINSHARED' '-DOPENSSL_THREADS' '-DBUILDING_NODE_EXTENSION' '-DIN_LIBXMLJS' '-D_REENTRANT' '-DHAVE_LIBPTHREAD' '-DHAVE_PTHREAD_H' '-DHAVE_UNISTD_H' '-DHAVE_RAND_R' -I/home/philip/.cache/node-gyp/24.15.0/include/node -I/home/philip/.cache/node-gyp/24.15.0/src -I/home/philip/.cache/node-gyp/24.15.0/deps/openssl/config -I/home/philip/.cache/node-gyp/24.15.0/deps/openssl/openssl/include -I/home/philip/.cache/node-gyp/24.15.0/deps/uv/include -I/home/philip/.cache/node-gyp/24.15.0/deps/zlib -I/home/philip/.cache/node-gyp/24.15.0/deps/v8/include -I../src/include -I../vendor/libxml2 -I../vendor/libxml2/include -I../vendor/libxml2/include/libxml -I../vendor/libxml2.config -I../vendor/libxml2.config/include -I../node_modules/nan  -fPIC -pthread -Wall -Wextra -Wno-unused-parameter -Wall -Wno-unused-result -O3 -m64 -O3 -fno-omit-frame-pointer -fno-rtti -fno-exceptions -fno-strict-aliasing -std=gnu++20 -MMD -MF ./Release/.deps/Release/obj.target/xmljs/src/xml_sax_parser.o.d.raw   -c
Release/obj.target/xmljs/src/xml_sax_parser.o: ../src/xml_sax_parser.cc \
 ../node_modules/nan/nan.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/node_version.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/uv.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/uv/errno.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/uv/version.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/uv/unix.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/uv/threadpool.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/uv/linux.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/node.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/cppgc/common.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8config.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-array-buffer.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-local-handle.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-handle-base.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-internal.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8config.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-memory-span.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-object.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-maybe.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/cppgc/internal/conditional-stack-allocated.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/cppgc/macros.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/cppgc/internal/compiler-specific.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/cppgc/type-traits.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-persistent-handle.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-weak-callback-info.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-primitive.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-data.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-value.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-sandbox.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-traced-handle.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-platform.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-source-location.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-container.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-context.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-snapshot.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-isolate.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-callbacks.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-promise.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-debug.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-script.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-message.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-embedder-heap.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-exception.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-function-callback.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-microtask.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-statistics.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-unwinder.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-embedder-state-scope.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-date.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-extension.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-external.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-function.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-template.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-initialization.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-json.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-locker.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-microtask-queue.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-primitive-object.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-proxy.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-regexp.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-typed-array.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-value-serializer.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-version.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8-wasm.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/node_version.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/node_api.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/js_native_api.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/js_native_api_types.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/node_api_types.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/node_buffer.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/node.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/node_object_wrap.h \
 ../node_modules/nan/nan_callbacks.h \
 ../node_modules/nan/nan_callbacks_12_inl.h \
 ../node_modules/nan/nan_maybe_43_inl.h \
 ../node_modules/nan/nan_converters.h \
 ../node_modules/nan/nan_converters_43_inl.h \
 ../node_modules/nan/nan_new.h \
 ../node_modules/nan/nan_implementation_12_inl.h \
 ../node_modules/nan/nan_persistent_12_inl.h \
 ../node_modules/nan/nan_weak.h ../node_modules/nan/nan_object_wrap.h \
 ../node_modules/nan/nan_private.h \
 ../node_modules/nan/nan_typedarray_contents.h \
 ../node_modules/nan/nan_json.h ../node_modules/nan/nan_scriptorigin.h \
 ../vendor/libxml2/include/libxml/parserInternals.h \
 ../vendor/libxml2.config/libxml/xmlversion.h \
 ../vendor/libxml2/include/libxml/xmlexports.h \
 ../vendor/libxml2/include/libxml/parser.h \
 ../vendor/libxml2/include/libxml/tree.h \
 ../vendor/libxml2/include/libxml/xmlstring.h \
 ../vendor/libxml2/include/libxml/xmlregexp.h \
 ../vendor/libxml2/include/libxml/dict.h \
 ../vendor/libxml2/include/libxml/hash.h \
 ../vendor/libxml2/include/libxml/valid.h \
 ../vendor/libxml2/include/libxml/xmlerror.h \
 ../vendor/libxml2/include/libxml/list.h \
 ../vendor/libxml2/include/libxml/xmlautomata.h \
 ../vendor/libxml2/include/libxml/entities.h \
 ../vendor/libxml2/include/libxml/encoding.h \
 ../vendor/libxml2/include/libxml/xmlIO.h \
 ../vendor/libxml2/include/libxml/globals.h \
 ../vendor/libxml2/include/libxml/SAX2.h \
 ../vendor/libxml2/include/libxml/xlink.h \
 ../vendor/libxml2/include/libxml/xmlmemory.h \
 ../vendor/libxml2/include/libxml/threads.h \
 ../vendor/libxml2/include/libxml/HTMLparser.h \
 ../vendor/libxml2/include/libxml/chvalid.h ../src/include/libxmljs.h \
 /home/philip/.cache/node-gyp/24.15.0/include/node/v8.h \
 ../src/include/xml_sax_parser.h
../src/xml_sax_parser.cc:
../node_modules/nan/nan.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/node_version.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/uv.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/uv/errno.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/uv/version.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/uv/unix.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/uv/threadpool.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/uv/linux.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/node.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/cppgc/common.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8config.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-array-buffer.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-local-handle.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-handle-base.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-internal.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8config.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-memory-span.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-object.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-maybe.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/cppgc/internal/conditional-stack-allocated.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/cppgc/macros.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/cppgc/internal/compiler-specific.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/cppgc/type-traits.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-persistent-handle.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-weak-callback-info.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-primitive.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-data.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-value.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-sandbox.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-traced-handle.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-platform.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-source-location.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-container.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-context.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-snapshot.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-isolate.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-callbacks.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-promise.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-debug.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-script.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-message.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-embedder-heap.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-exception.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-function-callback.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-microtask.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-statistics.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-unwinder.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-embedder-state-scope.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-date.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-extension.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-external.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-function.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-template.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-initialization.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-json.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-locker.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-microtask-queue.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-primitive-object.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-proxy.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-regexp.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-typed-array.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-value-serializer.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-version.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8-wasm.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/node_version.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/node_api.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/js_native_api.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/js_native_api_types.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/node_api_types.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/node_buffer.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/node.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/node_object_wrap.h:
../node_modules/nan/nan_callbacks.h:
../node_modules/nan/nan_callbacks_12_inl.h:
../node_modules/nan/nan_maybe_43_inl.h:
../node_modules/nan/nan_converters.h:
../node_modules/nan/nan_converters_43_inl.h:
../node_modules/nan/nan_new.h:
../node_modules/nan/nan_implementation_12_inl.h:
../node_modules/nan/nan_persistent_12_inl.h:
../node_modules/nan/nan_weak.h:
../node_modules/nan/nan_object_wrap.h:
../node_modules/nan/nan_private.h:
../node_modules/nan/nan_typedarray_contents.h:
../node_modules/nan/nan_json.h:
../node_modules/nan/nan_scriptorigin.h:
../vendor/libxml2/include/libxml/parserInternals.h:
../vendor/libxml2.config/libxml/xmlversion.h:
../vendor/libxml2/include/libxml/xmlexports.h:
../vendor/libxml2/include/libxml/parser.h:
../vendor/libxml2/include/libxml/tree.h:
../vendor/libxml2/include/libxml/xmlstring.h:
../vendor/libxml2/include/libxml/xmlregexp.h:
../vendor/libxml2/include/libxml/dict.h:
../vendor/libxml2/include/libxml/hash.h:
../vendor/libxml2/include/libxml/valid.h:
../vendor/libxml2/include/libxml/xmlerror.h:
../vendor/libxml2/include/libxml/list.h:
../vendor/libxml2/include/libxml/xmlautomata.h:
../vendor/libxml2/include/libxml/entities.h:
../vendor/libxml2/include/libxml/encoding.h:
../vendor/libxml2/include/libxml/xmlIO.h:
../vendor/libxml2/include/libxml/globals.h:
../vendor/libxml2/include/libxml/SAX2.h:
../vendor/libxml2/include/libxml/xlink.h:
../vendor/libxml2/include/libxml/xmlmemory.h:
../vendor/libxml2/include/libxml/threads.h:
../vendor/libxml2/include/libxml/HTMLparser.h:
../vendor/libxml2/include/libxml/chvalid.h:
../src/include/libxmljs.h:
/home/philip/.cache/node-gyp/24.15.0/include/node/v8.h:
../src/include/xml_sax_parser.h:
