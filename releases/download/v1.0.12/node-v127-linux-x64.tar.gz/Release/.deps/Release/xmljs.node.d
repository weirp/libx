cmd_Release/xmljs.node := ln -f "Release/obj.target/xmljs.node" "Release/xmljs.node" 2>/dev/null || (rm -rf "Release/xmljs.node" && cp -af "Release/obj.target/xmljs.node" "Release/xmljs.node")
